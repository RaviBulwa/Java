/**
 * Provides the view classes for the Fair Choice Vote application.
 *
 * @author Konrad Wydmuch
 * @version 5.0
 */
package fairchoice.view;
