package fairchoice.model;

import java.util.List;

/**
 * Immutable data of an election: the number of candidates and the preferences
 * of all voters.
 *
 * @param candidateCount number of candidates participating in the election
 * @param preferences candidate preferences of all voters; each inner list
 * represents one voter and contains candidate indices, starting from zero
 * @author Konrad Wydmuch
 * @version 1.0
 */
public record ElectionData(int candidateCount, List<List<Integer>> preferences) {

    /**
     * Creates election data and stores an unmodifiable copy of the
     * preferences.
     *
     * @param candidateCount number of candidates participating in the election
     * @param preferences candidate preferences of all voters
     */
    public ElectionData {
        preferences = preferences.stream().map(List::copyOf).toList();
    }
}
