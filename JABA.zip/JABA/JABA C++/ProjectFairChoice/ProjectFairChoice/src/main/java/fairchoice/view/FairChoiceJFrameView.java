package fairchoice.view;

import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import fairchoice.model.VoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/**
 * Represents the main graphical user interface of the FairChoice election
 * application.
 *
 * The view allows users to configure an election, enter voter preferences,
 * generate random preferences, clear the preferences table and display election
 * results calculated by the controller.
 *
 * @author Konrad Wydmuch
 * @version 6.0
 */
public class FairChoiceJFrameView extends javax.swing.JFrame {
    
    /**
     * Creates the main election window and initializes its components.
     */
    public FairChoiceJFrameView() {
        initComponents();

        this.jTablePreferences.getTableHeader().setReorderingAllowed(false);
        this.jTableResults.getTableHeader().setReorderingAllowed(false);
        
        this.jLabelPreferences.setDisplayedMnemonic('V');
        this.jLabelResults.setDisplayedMnemonic('R');
        
        this.jLabelCandidates.setDisplayedMnemonic('A');
        this.jLabelVoters.setDisplayedMnemonic('O');
    }

    /**
     * Registers a listener for the random preference generation button.
     *
     * @param listener action listener handling the button event
     */
    public void addGenerateRandomListener(ActionListener listener) {
        this.jButtonGenerateRandom.addActionListener(listener);
    }

    /**
     * Registers a listener for the table clearing button.
     *
     * @param listener action listener handling the button event
     */
    public void addClearTableListener(ActionListener listener) {
        this.jButtonClearTable.addActionListener(listener);
    }

    /**
     * Registers a listener for the election calculation button.
     *
     * @param listener action listener handling the button event
     */
    public void addElectListener(ActionListener listener) {
        this.jButtonElect.addActionListener(listener);
    }

    public int getCandidateCount() {
        return Integer.parseInt(this.jTextFieldCandicates.getText());
    }

    public int getVoterCount() {
        return Integer.parseInt(this.jTextFieldVoters.getText());
    }

    /**
     * Displays the election results in the results table.
     *
     * @param pluralityResults list containing Plurality scores for each
     * candidate
     * @param bordaResults list containing Borda scores for each candidate
     */
    public void displayResults(List<Integer> pluralityResults, List<Integer> bordaResults) {
        DefaultTableModel tableModel
                = (DefaultTableModel) this.jTableResults.getModel();

        for (int i = 0; i < pluralityResults.size(); i++) {
            tableModel.setValueAt(pluralityResults.get(i), i, 1);
            tableModel.setValueAt(bordaResults.get(i), i, 2);
        }
    }

    /**
     * Displays an error message in a graphical dialog window.
     *
     * @param message error message to be displayed
     */
    public void displayError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Sets the initial values of the candidate and voter input fields.
     *
     * @param candidateCount initial number of candidates
     * @param voterCount initial number of voters
     */
    public void setInitialValues(String candidateCount, String voterCount) {
        this.jTextFieldCandicates.setText(candidateCount);
        this.jTextFieldVoters.setText(voterCount);
    }
    
    /**
     * Creates the election results table with the specified number of candidates.
     *
     * @param candidateCount number of candidates
     */
    public void createResultsTable(int candidateCount) {

        Vector<String> columns = new Vector<>(List.of("Candidate", "Plurality", "Borda"));

        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (int i = 0; i < candidateCount; i++) {
            Vector<Object> row = new Vector<>();

            row.add("Candidate " + (i + 1));
            row.add(0);
            row.add(0);

            tableModel.addRow(row);
        }

        this.jTableResults.setModel(tableModel);
    }

    /**
     * Creates the voter preferences table with the specified dimensions.
     *
     * @param candidateCount number of candidates
     * @param voterCount number of voters
     */
    public void createPreferencesTable(int candidateCount, int voterCount) {

        Vector<String> columns = new Vector<>();

        columns.add("Voter");

        for (int i = 1; i <= candidateCount; i++) {
            columns.add(i + ". preference");
        }

        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
        };

        for (int i = 0; i < voterCount; i++) {
            Vector<Object> row = new Vector<>();

            row.add(i + 1);

            for (int j = 1; j <= candidateCount; j++) {
                row.add("");
            }

            tableModel.addRow(row);
        }

        this.jTablePreferences.setModel(tableModel);
    }
    
    /**
     * Displays generated voter preferences in the preferences table.
     *
     * @param preferences generated voter preference rankings
     */
    public void displayPreferences(List<List<Integer>> preferences) {
        int row = 0;

        for (List<Integer> ranking : preferences) {
            int column = 1;

            for (Integer candidate : ranking) {
                this.jTablePreferences.setValueAt(candidate + 1, row, column);
                column++;
            }

            row++;
        }
    }
    
    /**
     * Clears all candidate preferences while preserving the table structure.
     */
    public void clearPreferencesTable() {
        for (int i = 0; i < this.jTablePreferences.getRowCount(); i++) {
            for (int j = 1; j < this.jTablePreferences.getColumnCount(); j++) {
                this.jTablePreferences.setValueAt("", i, j);
            }
        }
    }

     /**
     * Reads voter preferences from the preferences table.
     *
     * Candidate numbers entered in the table are converted from
     * one-based numbering to zero-based indices.
     *
     * @return list of lists containing voter preferences
     * @throws VoteException if a preference is missing or is not a valid integer
     */
    public List<List<Integer>> getPreferences() throws VoteException {

        if (this.jTablePreferences.isEditing()
                && !this.jTablePreferences.getCellEditor().stopCellEditing()) {
            throw new VoteException("Please finish editing the current table cell.");
        }

        int voterCount = this.jTablePreferences.getRowCount();
        int candidateCount = this.jTablePreferences.getColumnCount() - 1;

        List<List<Integer>> preferences = new ArrayList<>();

        for (int i = 0; i < voterCount; i++) {

            List<Integer> ranking = new ArrayList<>();

            for (int j = 0; j < candidateCount; j++) {

                Object value = this.jTablePreferences.getValueAt(i, j + 1);

                if (value == null || value.toString().trim().isEmpty()) {
                    throw new VoteException(
                            "Missing preference in voter " + (i + 1) + "."
                    );
                }

                try {
                    ranking.add(Integer.parseInt(value.toString().trim()) - 1);
                } catch (NumberFormatException exception) {
                    throw new VoteException(
                            "Invalid candidate number in voter " + (i + 1) + "."
                    );
                }
            }

            preferences.add(ranking);
        }

        return preferences;
    }

    public int getPreferencesRowCount() {
        return this.jTablePreferences.getRowCount();
    }

    public int getPreferencesColumnCount() {
        return this.jTablePreferences.getColumnCount() - 1;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextFieldCandicates = new javax.swing.JTextField();
        jTextFieldVoters = new javax.swing.JTextField();
        jButtonElect = new javax.swing.JButton();
        jLabelCandidates = new javax.swing.JLabel();
        jLabelVoters = new javax.swing.JLabel();
        jScrollPanePreferences = new javax.swing.JScrollPane();
        jTablePreferences = new javax.swing.JTable();
        jButtonGenerateRandom = new javax.swing.JButton();
        jButtonClearTable = new javax.swing.JButton();
        jScrollPaneResults = new javax.swing.JScrollPane();
        jTableResults = new javax.swing.JTable();
        jLabelPreferences = new javax.swing.JLabel();
        jLabelResults = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("FairChoice - Election");
        setPreferredSize(new java.awt.Dimension(1000, 600));

        jTextFieldCandicates.setText("3");
        jTextFieldCandicates.setToolTipText("Enter the number of candidates.");
        jTextFieldCandicates.setMinimumSize(new java.awt.Dimension(90, 22));
        jTextFieldCandicates.setPreferredSize(new java.awt.Dimension(90, 22));
        jTextFieldCandicates.setVerifyInputWhenFocusTarget(false);

        jTextFieldVoters.setText("10");
        jTextFieldVoters.setToolTipText("Enter the number of voters.");
        jTextFieldVoters.setMinimumSize(new java.awt.Dimension(90, 22));
        jTextFieldVoters.setNextFocusableComponent(jTablePreferences);
        jTextFieldVoters.setPreferredSize(new java.awt.Dimension(90, 22));

        jButtonElect.setMnemonic('C');
        jButtonElect.setText("Calculate Results");
        jButtonElect.setToolTipText("Perform Election using inputed values.");
        jButtonElect.setNextFocusableComponent(jTableResults);

        jLabelCandidates.setLabelFor(jTextFieldCandicates);
        jLabelCandidates.setText("Candidates:");
        jLabelCandidates.setToolTipText("Enter the number of candidates.");

        jLabelVoters.setLabelFor(jTextFieldVoters);
        jLabelVoters.setText("Voters:");
        jLabelVoters.setToolTipText("Enter the number of voters.");

        jScrollPanePreferences.setNextFocusableComponent(jTablePreferences);

        jTablePreferences.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTablePreferences.setToolTipText("Table representing the voters and their votes.");
        jTablePreferences.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTablePreferences.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTablePreferences.setNextFocusableComponent(jButtonGenerateRandom);
        jTablePreferences.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPanePreferences.setViewportView(jTablePreferences);
        jTablePreferences.getAccessibleContext().setAccessibleName("Voters Table");

        jButtonGenerateRandom.setMnemonic('G');
        jButtonGenerateRandom.setText("Generate Random");
        jButtonGenerateRandom.setToolTipText("Fills the Preferences table with random values.");

        jButtonClearTable.setMnemonic('E');
        jButtonClearTable.setText("Erase Votes");
        jButtonClearTable.setToolTipText("Clears the preferences table");
        jButtonClearTable.setNextFocusableComponent(jButtonElect);

        jScrollPaneResults.setNextFocusableComponent(jTableResults);
        jScrollPaneResults.setOpaque(false);

        jTableResults.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableResults.setToolTipText("Table showing the election results.");
        jTableResults.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTableResults.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTableResults.setNextFocusableComponent(jTextFieldCandicates);
        jTableResults.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPaneResults.setViewportView(jTableResults);
        jTableResults.getAccessibleContext().setAccessibleName("Results Table");

        jLabelPreferences.setLabelFor(jTablePreferences);
        jLabelPreferences.setText("Votes table:");
        jLabelPreferences.setToolTipText("Table representing the voters and their votes.");

        jLabelResults.setLabelFor(jTableResults);
        jLabelResults.setText("Results table:");
        jLabelResults.setToolTipText("Table showing the election results.");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelCandidates, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldCandicates, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldVoters, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelVoters, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jButtonGenerateRandom)
                            .addGap(184, 184, 184)
                            .addComponent(jButtonClearTable))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelPreferences, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPanePreferences, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 153, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonElect)
                    .addComponent(jScrollPaneResults, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelResults, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(56, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelVoters, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelCandidates, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldCandicates, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldVoters, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonElect))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelPreferences)
                    .addComponent(jLabelResults))
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPanePreferences, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPaneResults, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonClearTable)
                    .addComponent(jButtonGenerateRandom))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jTextFieldCandicates.getAccessibleContext().setAccessibleName("Candidates");
        jTextFieldVoters.getAccessibleContext().setAccessibleName("Voters");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonClearTable;
    private javax.swing.JButton jButtonElect;
    private javax.swing.JButton jButtonGenerateRandom;
    private javax.swing.JLabel jLabelCandidates;
    private javax.swing.JLabel jLabelPreferences;
    private javax.swing.JLabel jLabelResults;
    private javax.swing.JLabel jLabelVoters;
    private javax.swing.JScrollPane jScrollPanePreferences;
    private javax.swing.JScrollPane jScrollPaneResults;
    private javax.swing.JTable jTablePreferences;
    private javax.swing.JTable jTableResults;
    private javax.swing.JTextField jTextFieldCandicates;
    private javax.swing.JTextField jTextFieldVoters;
    // End of variables declaration//GEN-END:variables
}
