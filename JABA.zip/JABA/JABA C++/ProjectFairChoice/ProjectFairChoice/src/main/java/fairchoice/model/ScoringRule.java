package fairchoice.model;

/**
 * Describes how many points a candidate receives for a given position in a
 * voter's ranking. Different voting methods are defined by different rules.
 *
 * @author Konrad Wydmuch
 * @version 1.0
 */
@FunctionalInterface
interface ScoringRule {

    /**
     * Calculates the points awarded for a position in a ranking.
     *
     * @param position position of the candidate in the ranking, starting from
     * zero
     * @param candidateCount total number of candidates
     * @return number of points awarded to the candidate
     */
    int points(int position, int candidateCount);
}
