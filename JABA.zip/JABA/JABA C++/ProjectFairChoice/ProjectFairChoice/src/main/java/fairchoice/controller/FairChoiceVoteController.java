package fairchoice.controller;

import fairchoice.model.FairChoiceVoteModel;
import fairchoice.model.VoteException;
import fairchoice.view.FairChoiceJFrameView;
import java.util.List;
import lombok.RequiredArgsConstructor;

/**
 * Controls the election process and connects the model with the view.
 *
 * @author Konrad Wydmuch
 * @version 4.0
 */
@RequiredArgsConstructor
public class FairChoiceVoteController {

    /**
     * Model responsible for storing election data and calculating results.
     */
    private final FairChoiceVoteModel voteModel;

    /**
     * View responsible for displaying election data and results.
     */
    private final FairChoiceJFrameView voteView;

    /**
     * Starts the graphical application and registers event listeners.
     */
    public void run() {
        this.voteView.setVisible(true);
        this.voteView.addGenerateRandomListener(e -> generateRandom());
        this.voteView.addClearTableListener(e -> clearTable());
        this.voteView.addElectListener(e -> startElection());
        
        this.generateRandom();
        this.startElection();
    }

    /**
     * Starts the application with initial candidate and voter counts.
     *
     * @param candidateCount initial number of candidates
     * @param voterCount initial number of voters
     */
    public void run(String candidateCount, String voterCount) {
        this.voteView.setInitialValues(candidateCount, voterCount);
        run();
    }

    /**
     * Calculates election results using the current GUI configuration.
     */
    private void startElection() {
        try {
            List<Integer> configuration = getConfiguration();

            int candidateCount = configuration.get(0);
            int voterCount = configuration.get(1);

            if (this.voteView.getPreferencesRowCount() != voterCount || this.voteView.getPreferencesColumnCount() != candidateCount) {
                this.voteView.displayError( "The table does not match the current configuration. Click Generate Random to create the table first.");
                return;
            }

            List<List<Integer>> preferences = this.voteView.getPreferences();

            this.voteModel.setElection(candidateCount, preferences);

            this.voteView.createResultsTable(candidateCount);

            List<Integer> pluralityResults = this.voteModel.calculatePlurality();
            List<Integer> bordaResults = this.voteModel.calculateBorda();

            this.voteView.displayResults(pluralityResults, bordaResults);

        } catch (VoteException exception) {
            this.voteView.displayError(exception.getMessage());
        }
 }
    
    /**
     * Generates random voter preferences using the current configuration.
     */
    private void generateRandom() {
        try {
            List<Integer> configuration = getConfiguration();

            int candidateCount = configuration.get(0);
            int voterCount = configuration.get(1);

            List<List<Integer>> preferences = this.voteModel.generateRandomPreferences(
                    candidateCount,
                    voterCount
            );

            this.voteView.createPreferencesTable(
                    candidateCount,
                    voterCount
            );
            
            this.voteView.displayPreferences(preferences);

        } catch (VoteException exception) {
            this.voteView.displayError(exception.getMessage());
        }
    }

    /**
     * Clears the preference table.
     */
    private void clearTable() {
        this.voteView.clearPreferencesTable();
    }

    /**
     * Reads and validates the election configuration from the GUI.
     *
     * @return a list containing candidate count at index 0 and voter count at
     * index 1
     * @throws VoteException if the configuration contains invalid values
     */
    private List<Integer> getConfiguration() throws VoteException {

        int candidateCount;
        int voterCount;

        try {
            candidateCount = this.voteView.getCandidateCount();
            voterCount = this.voteView.getVoterCount();

        } catch (NumberFormatException exception) {
            throw new VoteException("Please enter valid integer values.");
        }

        return List.of(candidateCount, voterCount);
    }
}
