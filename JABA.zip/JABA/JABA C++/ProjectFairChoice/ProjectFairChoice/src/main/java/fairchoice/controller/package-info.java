/**
 * Provides the controller classes for the Fair Choice Vote application.
 * 
 * @author Konrad Wydmuch
 * @version 4.0
 */
package fairchoice.controller;
