package fairchoice.model;

import lombok.experimental.StandardException;

/**
 * Represents an error related to election data or processing.
 * 
 * @author Konrad Wydmuch
 * @version 2.0
 */
@StandardException
public class VoteException extends Exception {
}
