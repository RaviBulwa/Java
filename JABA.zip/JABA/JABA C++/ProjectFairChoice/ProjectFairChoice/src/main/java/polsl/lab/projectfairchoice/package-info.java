/**
 * Contains the main class responsible for starting the FairChoice
 * @author Konrad Wydmuch
 * @version 3.0
 */
package polsl.lab.projectfairchoice;
