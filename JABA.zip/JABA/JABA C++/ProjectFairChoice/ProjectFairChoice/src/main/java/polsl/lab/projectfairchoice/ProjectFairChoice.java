package polsl.lab.projectfairchoice;

import fairchoice.view.FairChoiceJFrameView;
import fairchoice.controller.FairChoiceVoteController;
import fairchoice.model.FairChoiceVoteModel;

/**
 * Starts the Fair Choice voting application.
 *
 * @author Konrad Wydmuch
 * @version 3.0
 */
public class ProjectFairChoice {

     /**
     * Starts the application.
     *
     * Command-line arguments:
     * args[0] - initial number of candidates.
     * args[1] - initial number of voters.
     *
     * If exactly two valid arguments are provided, their values
     * are passed to the controller as initial GUI values.
     * Otherwise, the application starts with default GUI values.
     *
     * @param args command-line arguments in the order:
     *             candidate count, voter count
     */
    public static void main(String[] args) {
        
        javax.swing.SwingUtilities.invokeLater(() -> {
            FairChoiceJFrameView view = new FairChoiceJFrameView(); 
            FairChoiceVoteModel model = new FairChoiceVoteModel();

            FairChoiceVoteController controller = new FairChoiceVoteController(model, view);

            if(args.length == 2)
            {
                controller.run(args[0], args[1]);
            }
            else
            {
                controller.run();
            }
        });
    }
}
