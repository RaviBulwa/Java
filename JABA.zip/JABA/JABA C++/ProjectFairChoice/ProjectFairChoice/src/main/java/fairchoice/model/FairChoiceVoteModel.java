package fairchoice.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.IntStream;

/**
 * Represents an election with candidates and voter preferences. Calculates
 * election results using different voting methods.
 *
 * @author Konrad Wydmuch
 * @version 5.0
 */
public class FairChoiceVoteModel {

    /**
     * Election data: number of candidates and candidate preferences of all
     * voters. Each voter's preferences are a list of candidate indices,
     * starting from zero.
     */
    private ElectionData electionData;

    
 
    /**
     * Random number generator used to create voter preferences.
     */
    private Random random;
    
    /**
     * Creates an empty election model.
     */
    public FairChoiceVoteModel() {
        this.electionData = new ElectionData(0, List.of());
        this.random = new Random();
    }

    /**
     * Configures an election and validates all voter preferences.
     *
     * Each voter must rank every candidate exactly once.
     *
     * @param candidateCount number of candidates
     * @param preferences voter preference rankings, one list of candidate
     * indices for each voter
     * @throws VoteException if election configuration or preferences are invalid
     */
    public void setElection(int candidateCount, List<List<Integer>> preferences) throws VoteException {
        if (candidateCount < 2) {
            throw new VoteException(
                    "At least two candidates are required.");
        }

        if (preferences == null || preferences.isEmpty()) {
            throw new VoteException(
                    "At least one voter is required.");
        }

        for (int i = 0; i < preferences.size(); i++) {

            List<Integer> ranking = preferences.get(i);

            if (ranking == null || ranking.size() != candidateCount) {
                throw new VoteException(
                        "Invalid number of preferences for voter " + (i + 1) + ".");
            }

            Set<Integer> usedCandidates = new HashSet<>();

            for (Integer candidate : ranking) {

                if (candidate == null || candidate < 0 || candidate >= candidateCount) {
                    throw new VoteException(
                            "Invalid candidate number for voter " + (i + 1) + ".");
                }

                if (!usedCandidates.add(candidate)) {
                    throw new VoteException(
                            "Candidate " + (candidate + 1)
                            + " appears more than once in voter " + (i + 1) + ".");
                }
            }
        }

        this.electionData = new ElectionData(candidateCount, preferences);
    }

    /**
     * Counts first-place votes for each candidate.
     *
     * @return a list containing the vote count for each candidate
     */
    public List<Integer> calculatePlurality() {
        return calculateScores((position, candidateCount) -> position == 0 ? 1 : 0);
    }

    /**
     * Calculates candidate scores using the Borda count method.
     *
     * The first position receives candidateCount - 1 points. Each subsequent
     * position receives one point less. The last position receives zero points.
     *
     * @return a list containing the score for each candidate
     */
    public List<Integer> calculateBorda() {
        return calculateScores((position, candidateCount) -> candidateCount - 1 - position);
    }

    /**
     * Sums the points of every candidate over all voters according to the
     * given scoring rule.
     *
     * @param rule rule defining the points awarded for each ranking position
     * @return a list containing the total score of each candidate
     */
    private List<Integer> calculateScores(ScoringRule rule) {
        int candidateCount = this.electionData.candidateCount();

        return IntStream.range(0, candidateCount)
                .mapToObj(candidate -> this.electionData.preferences().stream()
                        .mapToInt(ranking -> rule.points(ranking.indexOf(candidate), candidateCount))
                        .sum())
                .toList();
    }

    /**
     * Generates random preferences for all voters.
     *
     * Each voter receives a random permutation of all candidates.
     *
     * @param candidateCount number of candidates
     * @param voterCount number of voters
     * @return generated voter preferences
     * @throws VoteException if the election configuration is invalid
     */
    public List<List<Integer>> generateRandomPreferences(
            int candidateCount, int voterCount) throws VoteException {

        if (candidateCount < 2 || voterCount < 1) {
            throw new VoteException(
                    "At least two candidates and one voter are required.");
        }

        List<List<Integer>> preferences = new ArrayList<>();

        for (int i = 0; i < voterCount; i++) {
            List<Integer> ranking = new ArrayList<>();

            for (int j = 0; j < candidateCount; j++) {
                ranking.add(j);
            }

            Collections.shuffle(ranking, this.random);
            preferences.add(ranking);
        }

        return preferences;
    }
}
